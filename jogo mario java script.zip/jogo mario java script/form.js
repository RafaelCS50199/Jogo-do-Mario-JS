document.getElementById('player-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const playerName = document.getElementById('player-name').value;
    
    if (playerName) {
        // Salvar o nome do jogador no localStorage
        localStorage.setItem('currentPlayer', playerName);

        // Redirecionar para a página do jogo
        window.location.href = 'index.html';
    }
});
