const mario = document.querySelector('.mario');
const pipe = document.querySelector('.pipe');
const scoreDisplay = document.getElementById('score');
const highscoreDisplay = document.getElementById('highscore');
const playerNameDisplay = document.getElementById('player-name');
const audioJogo = new Audio("mario.mp3");
const audiomorte = new Audio("gameover.mp3");
const audiopulo = new Audio("pulo.mp3");
// Recuperar o nome do jogador e atualizar a interface
let currentPlayer = localStorage.getItem('currentPlayer') || 'Player1';
playerNameDisplay.textContent = currentPlayer;


// Função que detecta o pulo do Mario
function jumpMario() {
    // Tocar o som quando Mario pular
    audiopulo.currentTime = 0; // Reinicia o som para o início
    audiopulo.play();
}

// Adiciona o evento de detecção de tecla para o pulo
document.addEventListener('keydown', (event) => {
    if (event.code === 'Space') { // Supondo que a tecla 'Espaço' faz o Mario pular
        jumpMario();
    }
});



// Função para obter o objeto de jogadores armazenado no localStorage
const getPlayers = () => {
    return JSON.parse(localStorage.getItem('players')) || {};
};

// Função para salvar o objeto de jogadores no localStorage
const savePlayers = (players) => {
    localStorage.setItem('players', JSON.stringify(players));
};

// Inicializar a pontuação e os jogadores
let score = 0;
let players = getPlayers();
let highscore = players[currentPlayer] || 0; // Obter o high score do jogador atual
highscoreDisplay.textContent = highscore;

// Variáveis para controle de velocidade
let gameSpeed = 11; // Intervalo inicial do loop em ms
const maxSpeed = 1; // Velocidade máxima, ou seja, o menor intervalo permitido
const speedIncrement = 0.1; // Taxa de aumento da velocidade

const updateScore = () => {
    score++;
    scoreDisplay.textContent = score;

    // Aumentar a velocidade do jogo com o tempo
    if (gameSpeed > maxSpeed) {
        gameSpeed -= speedIncrement;
        clearInterval(loop);
        startGameLoop();
    }

    // Ajustar a velocidade da animação do pipe
    const currentPipeSpeed = parseFloat(window.getComputedStyle(pipe).animationDuration.replace('s', ''));
    pipe.style.animationDuration = `${Math.max(currentPipeSpeed - speedIncrement * 0.1, 1)}s`; // 1s é a duração mínima da animação
}

const jump = () => {
    mario.classList.add('jump');
    setTimeout(() => {
        mario.classList.remove('jump');
    }, 500);
}

const gameLoop = () => {
    const pipePosition = pipe.offsetLeft;
    const marioPosition = +window.getComputedStyle(mario).bottom.replace('px', '');

    if (pipePosition <= 120 && pipePosition > 0 && marioPosition < 80) {
        pipe.style.animation = 'none';
        pipe.style.left = `${pipePosition}px`;

        mario.style.animation = 'none';
        mario.style.bottom = `${marioPosition}px`;

        mario.src = './game-over.png';
        mario.style.width = '75px';
        mario.style.marginLeft = '50px';

        audioJogo.pause(); // Para o áudio do jogo
        audiomorte.play();
        audiomorte.loop = true; // Faz o áudio tocar em loop contínuo
        clearInterval(loop);

        // Verificar e atualizar o highscore do jogador atual
        if (score > highscore) {
            players[currentPlayer] = score; // Atualizar o highscore do jogador atual
            savePlayers(players); // Salvar as pontuações no localStorage
            highscoreDisplay.textContent = score; // Atualizar o display do highscore
        }

        // Redirecionar para a página de ranking após um pequeno atraso
        setTimeout(() => {
            window.location.href = 'ranking.html';
        }, 5000);
    }

    updateScore(); // Incrementar a pontuação continuamente
}

// Função para iniciar o loop do jogo
const startGameLoop = () => {
    loop = setInterval(gameLoop, gameSpeed);

        // Tocar o áudio do jogo quando o loop iniciar
        audioJogo.play();
        audioJogo.loop = true; // Faz o áudio tocar em loop contínuo
}

let loop = null;
startGameLoop();

document.addEventListener('keydown', jump);

