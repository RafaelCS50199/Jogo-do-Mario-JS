// Função para obter o objeto de jogadores armazenado no localStorage
const getPlayers = () => {
    return JSON.parse(localStorage.getItem('players')) || {};
};

// Função para criar e exibir o ranking na tabela
const createRankingTable = () => {
    const players = getPlayers();
    const playersArray = Object.entries(players).sort((a, b) => b[1] - a[1]);

    const tbody = document.querySelector('#ranking-table tbody');
    tbody.innerHTML = ''; // Limpa o conteúdo anterior

    playersArray.forEach((player, index) => {
        const tr = document.createElement('tr');

        const positionTd = document.createElement('td');
        positionTd.textContent = index + 1;
        tr.appendChild(positionTd);

        const nameTd = document.createElement('td');
        nameTd.textContent = player[0];
        tr.appendChild(nameTd);

        const scoreTd = document.createElement('td');
        scoreTd.textContent = player[1];
        tr.appendChild(scoreTd);

        tbody.appendChild(tr);
    });
};

// Chama a função para criar o ranking quando a página é carregada
window.onload = createRankingTable;
